# Bayesian Causal Forests

Implementation of Bayesian causal forests (BCF): [https://arxiv.org/pdf/1706.09523.pdf](https://arxiv.org/pdf/1706.09523.pdf).